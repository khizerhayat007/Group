package pk.ciit.www;

public class Demo {

	public static void main(String[] args) {
		System.out.println("Assignment 03, Command pattren implementation");
		RecieverInterface receiverInterface = new ElectricKettle();
		ConcreteCommand command = new ConcreteCommand(receiverInterface);
		Invoker invoker = new Invoker(command);
		invoker.execute();
		System.out.println("**************************************");
		receiverInterface = new Juicer();
		command = new ConcreteCommand(receiverInterface);
		Invoker invoker2=new Invoker(command);
		invoker2.execute();
		System.out.println("**************************************");
		receiverInterface = new Light();
		command = new ConcreteCommand(receiverInterface);
		Invoker invoker3=new Invoker(command);
		invoker3.execute();
		System.out.println("**************************************");
		receiverInterface=new MicrowaveOven();
		command=new ConcreteCommand(receiverInterface);
		Invoker invoker4=new Invoker(command);
		invoker4.execute();
		System.out.println("**************************************");
		receiverInterface=new Stereo();
		command=new ConcreteCommand(receiverInterface);
		Invoker invoker5=new Invoker(command);
		invoker5.execute();
	}

}
