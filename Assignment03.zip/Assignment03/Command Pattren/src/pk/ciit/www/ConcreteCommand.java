package pk.ciit.www;

public class ConcreteCommand implements Command {
	private RecieverInterface reciever;
	

	public ConcreteCommand(RecieverInterface reciever) {
		
		this.reciever = reciever;
	}


	@Override
	public void execute() {
		this.reciever.switchOn();
		this.reciever.switchOff();
	}

}
