package pk.ciit.www;

public interface RecieverInterface {
public void switchOn();
public void switchOff();
}
