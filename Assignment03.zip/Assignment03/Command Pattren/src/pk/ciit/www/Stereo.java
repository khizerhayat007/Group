package pk.ciit.www;

public class Stereo implements RecieverInterface {

	@Override
	public void switchOn() {
		System.out.println("Stereo is switched On");

	}

	@Override
	public void switchOff() {
		System.out.println("Stereo is switched Off");

	}

}
