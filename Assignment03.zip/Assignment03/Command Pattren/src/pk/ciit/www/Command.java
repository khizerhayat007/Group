package pk.ciit.www;

public interface Command {
public void execute();
}
