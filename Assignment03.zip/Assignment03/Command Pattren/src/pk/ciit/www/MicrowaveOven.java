package pk.ciit.www;

public class MicrowaveOven implements RecieverInterface {

	@Override
	public void switchOn() {
		System.out.println("Microwave Oven is switched On");

	}

	@Override
	public void switchOff() {
		System.out.println("Microwave Oven is switched Off");

	}

}
