package pk.ciit.www;

public class Invoker {
	public Command command;

	public Invoker(Command command) {

		this.command = command;
	}

	public void execute() {
		this.command.execute();
	}

}
