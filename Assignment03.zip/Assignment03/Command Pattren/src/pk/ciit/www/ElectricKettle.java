package pk.ciit.www;

public class ElectricKettle implements RecieverInterface {

	@Override
	public void switchOn() {
	System.out.println("Electric kettle is switched On");

	}

	@Override
	public void switchOff() {
		System.out.println("Electric kettle is switched Off");

	}

}
