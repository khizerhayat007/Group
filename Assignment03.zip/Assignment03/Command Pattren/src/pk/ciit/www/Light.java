package pk.ciit.www;

public class Light implements RecieverInterface{

	@Override
	public void switchOn() {
		System.out.println("Light is switched On");
		
	}

	@Override
	public void switchOff() {
		System.out.println("Light is switched Off");
		
	}

}
