package pk.ciit.www;

public class Aggressive implements RobotStates{

	@Override
	public String execute() {
		return"Aggressive Behaviour, if find another robot attack it";
		
	}

}
