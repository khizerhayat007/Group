package pk.ciit.www;

public class Demo {

	public static void main(String[] args) {
		Context r1 = new Context("Big Robot");
		Context r2 = new Context("Small Robot");
		Context r3 = new Context("Innocent Robot");
		r1.setRobotStates(new Aggressive());
		r2.setRobotStates(new Defensive());
		r3.setRobotStates(new Normal());
		
	    r1.move();
	    System.out.println("***************************");
	    r2.move();
	    System.out.println("***************************");
	    r3.move();
	    System.out.println("***************************");
		
	    System.out.println("\nNew behaviours: " +
				"\nBig Robot gets really scared" +
				"\n,Small Robot becomes really mad because" +" "+
				"it's always attacked by other robots" +
				"\nInnocent Robot keeps its calm\r\n");
	    System.out.println("***************************");

		r1.setRobotStates(new Defensive());
		r2.setRobotStates(new Aggressive());

		r1.move();
		System.out.println("***************************");
		r2.move();
		System.out.println("***************************");
		r3.move();
		System.out.println("***************************");
	}

}
