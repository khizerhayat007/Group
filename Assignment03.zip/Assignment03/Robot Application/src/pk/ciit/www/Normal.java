package pk.ciit.www;

public class Normal implements RobotStates {

	@Override
	public String execute() {
		return "Normal Behaviour: if find another robot ignore it";

	}

}
