package pk.ciit.www;

public class Context implements RobotStates {
	RobotStates robotStates;
	String name;

	

	public Context(String name) {
		
		this.name = name;
	}

	public void setRobotStates(RobotStates robotStates) {
		this.robotStates = robotStates;
	}
	

	public RobotStates getRobotStates() {
		return robotStates;
	}
	public void move()
	{
		String command = robotStates.execute();
		System.out.println(command);
		System.out.println(this.name +" "+"is in"+" "+command);
		
	}
	

	public String getName() {
		return name;
	}

	@Override
	public String execute() {
		return robotStates.execute();

	}

}
