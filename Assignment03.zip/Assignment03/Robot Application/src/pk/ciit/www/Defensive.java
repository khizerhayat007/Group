package pk.ciit.www;

public class Defensive implements RobotStates{

	@Override
	public String execute() {
		return"Defensive Behaviour: if find another robot run from it";
		
	}

}
