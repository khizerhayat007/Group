package pk.ciit.www;

public interface RobotStates {
public String execute();
}
